package com.storage.document.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.storage.document.model.Document;
 
@Repository
public interface DocumentRepository
        extends JpaRepository<Document, Long> {

	public boolean existsByDocId(String docId);
	
	public Document findByDocId(String docId);
 
}
