package com.storage.document.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.storage.document.model.Document;
import com.storage.document.service.DocumentService;

@RestController
@RequestMapping("/storage/documents")
public class DocumentController {

	@Autowired
	DocumentService documentService;

	@PostMapping
	public ResponseEntity<String> createDocument(@RequestBody(required = true) String content) {
		Document document = documentService.createDocument(content);
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set("Content-Length", String.valueOf(document.getDocId().length()));
		return new ResponseEntity<>(document.getDocId(), responseHeaders, HttpStatus.CREATED);
	}
	
	
	@GetMapping("{docId}")
	public ResponseEntity<String> queryDocument(@PathVariable(value = "docId") String docId) {
	//public ResponseEntity<String> queryDocument(@RequestHeader(value = "dock") String docId) {
		String data = documentService.getDocumentByDocId(docId);
		HttpHeaders responseHeaders = new HttpHeaders();
		responseHeaders.set("Content-Length", String.valueOf(data.length()));
		return new ResponseEntity<>(data, responseHeaders, HttpStatus.OK);
	}
	
	@DeleteMapping("{docId}")
	public ResponseEntity<HttpStatus> deleteDocument(@PathVariable(value = "docId") String docId) {
		documentService.deleteDocumentByDocId(docId);		
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}
	
	
	@PutMapping("{docId}")
	public ResponseEntity<HttpStatus> updateDocument(@RequestBody(required = true) String content,@PathVariable(value = "docId") String docId) {
		documentService.updateDocumentByDocId(docId, content);
		return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	}

}