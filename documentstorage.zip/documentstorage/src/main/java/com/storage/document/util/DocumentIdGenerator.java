package com.storage.document.util;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.storage.document.repository.DocumentRepository;

@Component
public class DocumentIdGenerator {

	private static final String ALPHA_NUM = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	private static final int DOC_ID_LENGTH = 20;
	@Autowired
	private DocumentRepository documentRepository; 

	
	public String generateUniqueDocId() {
		String docId= generateRandomDocId();
		boolean exist = documentRepository.existsByDocId(docId);
		if(exist) {
			generateUniqueDocId();
		}
		return docId;
	}
	
	
	
	private String generateRandomDocId() {
		final StringBuilder builder = new StringBuilder(DOC_ID_LENGTH);
		Random random = new Random();
		for (int i = 0; i < DOC_ID_LENGTH; i++) {
			int index = random.nextInt(ALPHA_NUM.length());
			builder.append(ALPHA_NUM.charAt(index));
		}
		return builder.toString();
	}

}
