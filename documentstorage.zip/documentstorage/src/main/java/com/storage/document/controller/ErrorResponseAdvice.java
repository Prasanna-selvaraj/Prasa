package com.storage.document.controller;


import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.storage.document.exception.DocumentStorageException;


@RestControllerAdvice
public class ErrorResponseAdvice {

	
	@ExceptionHandler(value = DocumentStorageException.class)
	public ResponseEntity<String> handleException(DocumentStorageException exp) {		
		return new ResponseEntity<>(exp.getMessage(), exp.getHttpStatus());
	}


}