package com.storage.document.service;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.storage.document.exception.DocumentStorageException;
import com.storage.document.model.Document;
import com.storage.document.repository.DocumentRepository;
import com.storage.document.util.DocumentIdGenerator;

@Service
public class DocumentService {

	private static final String INVALID_DOC_ID = "Invalid Doc Id";
	@Autowired
	DocumentRepository repository;
	@Autowired
	DocumentIdGenerator docIdGenerator;

	private static final String PATH = "C:\\docstore";
	private static final String EXT = ".txt";

	public DocumentService() {
		File f = new File(PATH);
		if (!f.exists()) {
			f.mkdir();
		}
	}

	public Document createDocument(String content) {
		Document document = new Document();
		document.setDocId(docIdGenerator.generateUniqueDocId());
		String fileName = PATH + File.separator + document.getDocId() + EXT;
		File file = new File(fileName);
		try (FileWriter fileWriter = new FileWriter(file)) {
			fileWriter.write(content);
		} catch (IOException e) {
			throw new DocumentStorageException("Unable to save the file" + e.getMessage(),
					HttpStatus.INTERNAL_SERVER_ERROR);
		}
		document.setFilename(fileName);
		document.setSize(file.length());
		repository.save(document);
		return document;
	}

	public String getDocumentByDocId(String docId) {
		if (repository.existsByDocId(docId)) {
			Document document = repository.findByDocId(docId);
			try {
				return new String(Files.readAllBytes(Paths.get(document.getFilename())));
			} catch (IOException e) {
				throw new DocumentStorageException("Unable to read from file:" + e.getMessage(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} else {
			throw new DocumentStorageException(INVALID_DOC_ID, HttpStatus.NOT_FOUND);
		}
	}

	public Document deleteDocumentByDocId(String docId) {
		if (repository.existsByDocId(docId)) {
			Document document = repository.findByDocId(docId);
			try {
				Files.delete(Paths.get(document.getFilename()));
				repository.delete(document);
				return document;
			} catch (IOException e) {
				throw new DocumentStorageException("Unable to read from file:" + e.getMessage(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}

		} else {
			throw new DocumentStorageException(INVALID_DOC_ID, HttpStatus.NOT_FOUND);
		}
	}

	public Document updateDocumentByDocId(String docId, String content) {
		if (repository.existsByDocId(docId)) {
			Document document = repository.findByDocId(docId);
			String fileName = PATH + File.separator + document.getDocId() + EXT;
			File file = new File(fileName);
			try (FileWriter fileWriter = new FileWriter(file, false)) {
				fileWriter.write(content);
			} catch (IOException e) {
				throw new DocumentStorageException("Unable to write it to the file:" + e.getMessage(),
						HttpStatus.INTERNAL_SERVER_ERROR);
			}
			document.setFilename(fileName);
			document.setSize(file.length());
			repository.save(document);
			return document;

		} else {
			throw new DocumentStorageException(INVALID_DOC_ID, HttpStatus.NOT_FOUND);
		}
	}

}